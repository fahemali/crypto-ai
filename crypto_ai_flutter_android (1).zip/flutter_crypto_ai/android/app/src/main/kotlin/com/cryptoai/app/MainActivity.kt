package com.cryptoai.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
