import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'l10n/app_localizations.dart';
import 'screens/home_shell.dart';
import 'state/market_simulation_controller.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CryptoAiApp());
}

class CryptoAiApp extends StatefulWidget {
  const CryptoAiApp({super.key, this.autoStartTimer = true});

  final bool autoStartTimer;

  @override
  State<CryptoAiApp> createState() => _CryptoAiAppState();
}

class _CryptoAiAppState extends State<CryptoAiApp> {
  late final MarketSimulationController _controller;

  @override
  void initState() {
    super.initState();
    _controller =
        MarketSimulationController(autoStartTimer: widget.autoStartTimer);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return MaterialApp(
          title: 'Crypto AI',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.darkTheme(),
          locale: _controller.locale,
          supportedLocales: AppLocalizations.supportedLocales,
          localizationsDelegates: const [
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: HomeShell(controller: _controller),
        );
      },
    );
  }
}
