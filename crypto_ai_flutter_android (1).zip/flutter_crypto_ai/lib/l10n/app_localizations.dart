import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

class AppLocalizations {
  AppLocalizations(this.locale);

  final Locale locale;

  static AppLocalizations of(BuildContext context) {
    final result =
        Localizations.of<AppLocalizations>(context, AppLocalizations);
    assert(result != null, 'No AppLocalizations found in context');
    return result!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  static const List<Locale> supportedLocales = [
    Locale('en'),
    Locale('ar'),
  ];

  bool get isArabic => locale.languageCode == 'ar';

  static const Map<String, Map<String, String>> _localizedValues = {
    'en': {
      'appTitle': 'Crypto AI',
      'educationalBadge': 'Educational Paper Simulation Only',
      'navMarket': 'Market',
      'navSimulator': 'Paper Lab',
      'navAcademy': 'Academy',
      'navSettings': 'Settings',
      'marketOverview': 'Simulated Market Overview',
      'searchAssets': 'Search simulated assets...',
      'allCategories': 'All',
      'layer1Category': 'Layer 1',
      'defiCategory': 'DeFi',
      'aiComputeCategory': 'Compute',
      'marketCap': 'Simulated Cap',
      'volume24h': '24h Sim Vol',
      'rsi14': 'RSI (14)',
      'range24h': '24h Range',
      'openInSimulator': 'Practice in Paper Lab',
      'virtualBalance': 'Virtual Paper Balance',
      'portfolioEquity': 'Total Virtual Equity',
      'unrealizedPnl': 'Unrealized PnL',
      'buyOrder': 'Simulate Buy',
      'sellOrder': 'Simulate Sell',
      'quantityLabel': 'Quantity',
      'estimatedTotal': 'Estimated Virtual Cost',
      'executePaperOrder': 'Place Virtual Order',
      'resetPortfolio': 'Reset \$100,000 Portfolio',
      'holdingsTitle': 'Virtual Holdings',
      'noHoldings': 'No virtual positions yet. Select an asset to practice.',
      'orderHistory': 'Simulated Order Log',
      'insufficientBalance': 'Insufficient virtual USD balance for simulation.',
      'insufficientHoldings': 'Insufficient virtual quantity for simulated sell.',
      'invalidQuantity': 'Enter a valid positive quantity.',
      'orderSuccessBuy': 'Simulated buy recorded in virtual portfolio.',
      'orderSuccessSell': 'Simulated sell recorded in virtual portfolio.',
      'academyTitle': 'Crypto Market Academy',
      'academySubtitle':
          'Interactive concepts & indicators — zero real financial risk.',
      'rsiLabTitle': 'Interactive RSI (14) Concept Lab',
      'rsiOversold': 'Oversold Zone (< 30)',
      'rsiNeutral': 'Neutral Momentum (30 - 70)',
      'rsiOverbought': 'Overbought Zone (> 70)',
      'settingsTitle': 'Simulation Settings',
      'languageLabel': 'Interface Language',
      'liveTicksLabel': 'Simulated 3s Price Ticks',
      'disclaimerTitle': 'Educational Purpose Notice',
      'disclaimerBody':
          'All prices, market caps, charts, and \$100,000 balances are synthetic offline mock data. Crypto AI does not connect to real exchanges or execute real trades.',
      'avgEntry': 'Avg Entry',
      'noOrdersYet': 'No virtual orders placed yet.',
      'selectAsset': 'Select Asset',
      'lesson1Title': 'Market Capitalization vs. Token Price',
      'lesson1Body':
          'Market cap equals circulating supply multiplied by unit price. Comparing token prices alone without supply context can mislead beginners.',
      'lesson2Title': 'Paper Simulation & Risk Discipline',
      'lesson2Body':
          'Practicing position sizing with virtual capital teaches how volatility affects unrealized PnL before ever risking real funds.',
      'lesson3Title': 'Reading Trend & Support Zones',
      'lesson3Body':
          'Sparkline momentum and 24-hour high/low ranges help visualize volatility bands rather than predicting guaranteed future moves.',
    },
    'ar': {
      'appTitle': 'Crypto AI',
      'educationalBadge': 'محاكاة تعليمية ورقية فقط',
      'navMarket': 'السوق',
      'navSimulator': 'المحاكاة',
      'navAcademy': 'الأكاديمية',
      'navSettings': 'الإعدادات',
      'marketOverview': 'نظرة عامة على السوق المحاكى',
      'searchAssets': 'ابحث عن عملة رقمية وهمية...',
      'allCategories': 'الكل',
      'layer1Category': 'الطبقة الأولى',
      'defiCategory': 'التمويل اللامركزي',
      'aiComputeCategory': 'الحوسبة',
      'marketCap': 'القيمة التقديرية',
      'volume24h': 'حجم 24 ساعة',
      'rsi14': 'مؤشر القوة النسبية (14)',
      'range24h': 'نطاق 24 ساعة',
      'openInSimulator': 'تدرّب في المحاكاة الورقية',
      'virtualBalance': 'الرصيد الورقي الافتراضي',
      'portfolioEquity': 'إجمالي قيمة المحفظة',
      'unrealizedPnl': 'الربح / الخسارة غير المحققة',
      'buyOrder': 'محاكاة شراء',
      'sellOrder': 'محاكاة بيع',
      'quantityLabel': 'الكمية',
      'estimatedTotal': 'التكلفة الافتراضية المقدرة',
      'executePaperOrder': 'تنفيذ أمر افتراضي',
      'resetPortfolio': 'إعادة ضبط المحفظة (100,000\$)',
      'holdingsTitle': 'الممتلكات الافتراضية',
      'noHoldings': 'لا توجد مراكز افتراضية بعد. اختر عملة للتدريب.',
      'orderHistory': 'سجل الأوامر المحاكاة',
      'insufficientBalance': 'الرصيد الافتراضي غير كافٍ لإتمام هذه المحاكاة.',
      'insufficientHoldings': 'الكمية الافتراضية غير كافية لمحاكاة البيع.',
      'invalidQuantity': 'أدخل كمية موجبة صالحة.',
      'orderSuccessBuy': 'تم تسجيل أمر الشراء الافتراضي في محفظتك.',
      'orderSuccessSell': 'تم تسجيل أمر البيع الافتراضي في محفظتك.',
      'academyTitle': 'أكاديمية سوق العملات الرقمية',
      'academySubtitle': 'مفاهيم تفاعلية ومؤشرات محاكاة — بدون أي مخاطر حقيقية.',
      'rsiLabTitle': 'مختبر مفهوم RSI (14) التفاعلي',
      'rsiOversold': 'منطقة تشبع بيعي (< 30)',
      'rsiNeutral': 'زخم متوازن (30 - 70)',
      'rsiOverbought': 'منطقة تشبع شرائي (> 70)',
      'settingsTitle': 'إعدادات المحاكاة',
      'languageLabel': 'لغة الواجهة',
      'liveTicksLabel': 'تحديث الأسعار الوهمية كل 3 ثوانٍ',
      'disclaimerTitle': 'تنويه تعليمي هام',
      'disclaimerBody':
          'جميع الأسعار والقيم السوقية والرسوم البيانية ورصيد 100,000 دولار هي بيانات محاكاة تعليمية غير متصلة بالإنترنت. لا يرتبط التطبيق بأي منصات تداول حقيقية.',
      'avgEntry': 'متوسط الدخول',
      'noOrdersYet': 'لم يتم تسجيل أوامر افتراضية بعد.',
      'selectAsset': 'اختر الأصل',
      'lesson1Title': 'القيمة السوقية مقابل سعر الوحدة',
      'lesson1Body':
          'تُحسب القيمة السوقية بضرب المعروض المتداول في سعر الوحدة. مقارنة سعر العملة فقط دون حجم المعروض قد تعطي تصوراً غير دقيق.',
      'lesson2Title': 'التداول الورقي وإدارة المخاطر',
      'lesson2Body':
          'التدرّب برصيد افتراضي يعلّمك تأثير التقلبات السعرية على الأرباح والخسائر غير المحققة قبل التعامل مع أي أسواق حقيقية.',
      'lesson3Title': 'قراءة الزخم ونطاق التذبذب',
      'lesson3Body':
          'الرسوم المصغرة ونطاق 24 ساعة تساعد على فهم حدة التقلب التاريخي وليست أداة للتنبؤ المضمون بالمستقبل.',
    },
  };

  String text(String key) {
    final map = _localizedValues[locale.languageCode] ?? _localizedValues['en']!;
    return map[key] ?? _localizedValues['en']![key] ?? key;
  }
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'ar'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(AppLocalizations(locale));
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
