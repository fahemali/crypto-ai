enum AssetCategory {
  layer1,
  defi,
  compute,
}

enum OrderSide {
  buy,
  sell,
}

class CryptoAsset {
  const CryptoAsset({
    required this.id,
    required this.symbol,
    required this.nameEn,
    required this.nameAr,
    required this.category,
    required this.priceUsd,
    required this.change24hPercent,
    required this.marketCapBillions,
    required this.volume24hBillions,
    required this.low24h,
    required this.high24h,
    required this.rsi14,
    required this.sparkline,
  });

  final String id;
  final String symbol;
  final String nameEn;
  final String nameAr;
  final AssetCategory category;
  final double priceUsd;
  final double change24hPercent;
  final double marketCapBillions;
  final double volume24hBillions;
  final double low24h;
  final double high24h;
  final double rsi14;
  final List<double> sparkline;

  String localizedName(bool isArabic) => isArabic ? nameAr : nameEn;

  CryptoAsset copyWith({
    double? priceUsd,
    double? change24hPercent,
    double? low24h,
    double? high24h,
    double? rsi14,
    List<double>? sparkline,
  }) {
    return CryptoAsset(
      id: id,
      symbol: symbol,
      nameEn: nameEn,
      nameAr: nameAr,
      category: category,
      priceUsd: priceUsd ?? this.priceUsd,
      change24hPercent: change24hPercent ?? this.change24hPercent,
      marketCapBillions: marketCapBillions,
      volume24hBillions: volume24hBillions,
      low24h: low24h ?? this.low24h,
      high24h: high24h ?? this.high24h,
      rsi14: rsi14 ?? this.rsi14,
      sparkline: sparkline ?? this.sparkline,
    );
  }
}

class PaperHolding {
  const PaperHolding({
    required this.symbol,
    required this.quantity,
    required this.avgEntryPrice,
  });

  final String symbol;
  final double quantity;
  final double avgEntryPrice;
}

class PaperOrder {
  const PaperOrder({
    required this.id,
    required this.symbol,
    required this.side,
    required this.quantity,
    required this.priceUsd,
    required this.timestamp,
  });

  final String id;
  final String symbol;
  final OrderSide side;
  final double quantity;
  final double priceUsd;
  final DateTime timestamp;

  double get totalUsd => quantity * priceUsd;
}
