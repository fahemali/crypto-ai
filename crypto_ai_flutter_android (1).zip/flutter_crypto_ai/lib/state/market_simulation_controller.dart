import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../data/mock_market_data.dart';
import '../models/crypto_asset.dart';

enum OrderStatusCode {
  successBuy,
  successSell,
  invalidQuantity,
  insufficientBalance,
  insufficientHoldings,
}

class MarketSimulationController extends ChangeNotifier {
  MarketSimulationController({bool autoStartTimer = true})
      : _assets = MockMarketData.initialAssets() {
    if (autoStartTimer) {
      startSimulationTimer();
    }
  }

  static const double initialVirtualBalance = 100000.0;

  List<CryptoAsset> _assets;
  double _virtualUsdBalance = initialVirtualBalance;
  final Map<String, PaperHolding> _holdings = {};
  final List<PaperOrder> _orders = [];
  String _selectedSymbol = 'BTC';
  Locale _locale = const Locale('en');
  bool _liveTicksEnabled = true;
  int _tickStep = 0;
  Timer? _timer;

  List<CryptoAsset> get assets => List.unmodifiable(_assets);
  double get virtualUsdBalance => _virtualUsdBalance;
  List<PaperHolding> get holdings => _holdings.values.toList(growable: false);
  List<PaperOrder> get orders => List.unmodifiable(_orders);
  String get selectedSymbol => _selectedSymbol;
  Locale get locale => _locale;
  bool get liveTicksEnabled => _liveTicksEnabled;

  CryptoAsset get selectedAsset {
    return _assets.firstWhere(
      (a) => a.symbol == _selectedSymbol,
      orElse: () => _assets.first,
    );
  }

  double get holdingsMarketValue {
    double total = 0;
    for (final holding in _holdings.values) {
      final asset = _assets.firstWhere(
        (a) => a.symbol == holding.symbol,
        orElse: () => _assets.first,
      );
      total += holding.quantity * asset.priceUsd;
    }
    return total;
  }

  double get totalVirtualEquity => _virtualUsdBalance + holdingsMarketValue;

  double get unrealizedPnl {
    double pnl = 0;
    for (final holding in _holdings.values) {
      final asset = _assets.firstWhere(
        (a) => a.symbol == holding.symbol,
        orElse: () => _assets.first,
      );
      pnl += (asset.priceUsd - holding.avgEntryPrice) * holding.quantity;
    }
    return pnl;
  }

  void setLocale(Locale newLocale) {
    if (_locale == newLocale) return;
    _locale = newLocale;
    notifyListeners();
  }

  void selectAsset(String symbol) {
    if (_selectedSymbol == symbol) return;
    _selectedSymbol = symbol;
    notifyListeners();
  }

  void toggleLiveTicks(bool enabled) {
    _liveTicksEnabled = enabled;
    if (enabled) {
      startSimulationTimer();
    } else {
      _timer?.cancel();
      _timer = null;
    }
    notifyListeners();
  }

  void startSimulationTimer() {
    _timer?.cancel();
    if (!_liveTicksEnabled) return;
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      simulateTick();
    });
  }

  /// Deterministic offline price fluctuation for educational visualization.
  void simulateTick() {
    _tickStep += 1;
    _assets = List<CryptoAsset>.generate(_assets.length, (index) {
      final asset = _assets[index];
      final wave = math.sin((_tickStep + 1) * 0.85 + index * 1.37) * 0.0048 +
          math.cos((_tickStep + 2) * 0.41 + index * 0.73) * 0.0024;
      final nextPrice = math.max(0.01, asset.priceUsd * (1.0 + wave));
      final nextChange = asset.change24hPercent + wave * 100.0;
      final nextRsi = (asset.rsi14 + wave * 320.0).clamp(18.0, 84.0);
      final updatedSparkline = List<double>.from(asset.sparkline.skip(1))
        ..add(nextPrice);

      return asset.copyWith(
        priceUsd: nextPrice,
        change24hPercent: nextChange,
        low24h: math.min(asset.low24h, nextPrice),
        high24h: math.max(asset.high24h, nextPrice),
        rsi14: nextRsi,
        sparkline: updatedSparkline,
      );
    });
    notifyListeners();
  }

  OrderStatusCode executePaperOrder({
    required String symbol,
    required OrderSide side,
    required double quantity,
  }) {
    if (quantity.isNaN || quantity <= 0) {
      return OrderStatusCode.invalidQuantity;
    }

    final asset = _assets.firstWhere((a) => a.symbol == symbol);
    final notional = quantity * asset.priceUsd;

    if (side == OrderSide.buy) {
      if (notional > _virtualUsdBalance) {
        return OrderStatusCode.insufficientBalance;
      }
      _virtualUsdBalance -= notional;

      final existing = _holdings[symbol];
      if (existing == null) {
        _holdings[symbol] = PaperHolding(
          symbol: symbol,
          quantity: quantity,
          avgEntryPrice: asset.priceUsd,
        );
      } else {
        final combinedQty = existing.quantity + quantity;
        final weightedEntry = ((existing.quantity * existing.avgEntryPrice) +
                (quantity * asset.priceUsd)) /
            combinedQty;
        _holdings[symbol] = PaperHolding(
          symbol: symbol,
          quantity: combinedQty,
          avgEntryPrice: weightedEntry,
        );
      }

      _orders.insert(
        0,
        PaperOrder(
          id: 'SIM-${DateTime.now().microsecondsSinceEpoch}',
          symbol: symbol,
          side: OrderSide.buy,
          quantity: quantity,
          priceUsd: asset.priceUsd,
          timestamp: DateTime.now(),
        ),
      );
      notifyListeners();
      return OrderStatusCode.successBuy;
    } else {
      final existing = _holdings[symbol];
      if (existing == null || quantity > existing.quantity + 1e-9) {
        return OrderStatusCode.insufficientHoldings;
      }
      _virtualUsdBalance += notional;
      final remaining = existing.quantity - quantity;
      if (remaining <= 1e-8) {
        _holdings.remove(symbol);
      } else {
        _holdings[symbol] = PaperHolding(
          symbol: symbol,
          quantity: remaining,
          avgEntryPrice: existing.avgEntryPrice,
        );
      }

      _orders.insert(
        0,
        PaperOrder(
          id: 'SIM-${DateTime.now().microsecondsSinceEpoch}',
          symbol: symbol,
          side: OrderSide.sell,
          quantity: quantity,
          priceUsd: asset.priceUsd,
          timestamp: DateTime.now(),
        ),
      );
      notifyListeners();
      return OrderStatusCode.successSell;
    }
  }

  void resetPortfolio() {
    _virtualUsdBalance = initialVirtualBalance;
    _holdings.clear();
    _orders.clear();
    notifyListeners();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
