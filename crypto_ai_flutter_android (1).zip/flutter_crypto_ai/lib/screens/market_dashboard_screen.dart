import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';
import '../models/crypto_asset.dart';
import '../state/market_simulation_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/asset_detail_sheet.dart';
import '../widgets/sparkline_chart.dart';

class MarketDashboardScreen extends StatefulWidget {
  const MarketDashboardScreen({
    super.key,
    required this.controller,
    required this.onNavigateToSimulator,
  });

  final MarketSimulationController controller;
  final VoidCallback onNavigateToSimulator;

  @override
  State<MarketDashboardScreen> createState() => _MarketDashboardScreenState();
}

class _MarketDashboardScreenState extends State<MarketDashboardScreen> {
  String _query = '';
  AssetCategory? _selectedCategory;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final assets = widget.controller.assets.where((asset) {
      final matchesCategory =
          _selectedCategory == null || asset.category == _selectedCategory;
      final q = _query.trim().toLowerCase();
      final matchesQuery = q.isEmpty ||
          asset.symbol.toLowerCase().contains(q) ||
          asset.nameEn.toLowerCase().contains(q) ||
          asset.nameAr.contains(q);
      return matchesCategory && matchesQuery;
    }).toList(growable: false);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: AppTheme.cardDecoration(highlighted: true),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                l10n.text('portfolioEquity'),
                style: const TextStyle(
                  fontSize: 12,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                '\$${widget.controller.totalVirtualEquity.toStringAsFixed(2)}',
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary,
                  fontFeatures: [FontFeature.tabularFigures()],
                ),
              ),
              const SizedBox(height: 4),
              Text(
                l10n.text('educationalBadge'),
                style: const TextStyle(
                  fontSize: 12,
                  color: AppTheme.accentCyan,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          onChanged: (value) => setState(() => _query = value),
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search, size: 20),
            hintText: l10n.text('searchAssets'),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              _CategoryButton(
                label: l10n.text('allCategories'),
                selected: _selectedCategory == null,
                onTap: () => setState(() => _selectedCategory = null),
              ),
              const SizedBox(width: 8),
              _CategoryButton(
                label: l10n.text('layer1Category'),
                selected: _selectedCategory == AssetCategory.layer1,
                onTap: () =>
                    setState(() => _selectedCategory = AssetCategory.layer1),
              ),
              const SizedBox(width: 8),
              _CategoryButton(
                label: l10n.text('defiCategory'),
                selected: _selectedCategory == AssetCategory.defi,
                onTap: () =>
                    setState(() => _selectedCategory = AssetCategory.defi),
              ),
              const SizedBox(width: 8),
              _CategoryButton(
                label: l10n.text('aiComputeCategory'),
                selected: _selectedCategory == AssetCategory.compute,
                onTap: () =>
                    setState(() => _selectedCategory = AssetCategory.compute),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Text(
          l10n.text('marketOverview'),
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimary,
          ),
        ),
        const SizedBox(height: 10),
        ...assets.map((asset) {
          final isUp = asset.change24hPercent >= 0;
          final color =
              isUp ? AppTheme.accentEmerald : AppTheme.accentCrimson;
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () {
                showModalBottomSheet<void>(
                  context: context,
                  backgroundColor: Colors.transparent,
                  isScrollControlled: true,
                  builder: (_) => AssetDetailSheet(
                    asset: asset,
                    onPracticeInSimulator: () {
                      widget.controller.selectAsset(asset.symbol);
                      widget.onNavigateToSimulator();
                    },
                  ),
                );
              },
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: AppTheme.cardDecoration(),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceElevated,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppTheme.hairline),
                      ),
                      child: Text(
                        asset.symbol,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.accentCyan,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            asset.localizedName(l10n.isArabic),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            'RSI ${asset.rsi14.toStringAsFixed(0)} · \$${asset.marketCapBillions.toStringAsFixed(1)}B',
                            style: const TextStyle(
                              fontSize: 11,
                              color: AppTheme.textSecondary,
                              fontFeatures: [FontFeature.tabularFigures()],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 68,
                      child: SparklineChart(
                        points: asset.sparkline,
                        color: color,
                        height: 34,
                        strokeWidth: 1.8,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '\$${asset.priceUsd.toStringAsFixed(asset.priceUsd < 10 ? 2 : 2)}',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            fontFeatures: [FontFeature.tabularFigures()],
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${isUp ? '+' : ''}${asset.change24hPercent.toStringAsFixed(2)}%',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: color,
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ],
    );
  }
}

class _CategoryButton extends StatelessWidget {
  const _CategoryButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        backgroundColor: selected
            ? AppTheme.accentCyan.withOpacity(0.16)
            : AppTheme.surface,
        foregroundColor:
            selected ? AppTheme.accentCyan : AppTheme.textSecondary,
        side: BorderSide(
          color: selected ? AppTheme.accentCyan : AppTheme.hairline,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      ),
      child: Text(
        label,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
      ),
    );
  }
}
