import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';
import '../theme/app_theme.dart';

class AcademyScreen extends StatefulWidget {
  const AcademyScreen({super.key});

  @override
  State<AcademyScreen> createState() => _AcademyScreenState();
}

class _AcademyScreenState extends State<AcademyScreen> {
  double _simulatedRsi = 54.0;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    final String zoneLabel;
    final Color zoneColor;
    if (_simulatedRsi < 30) {
      zoneLabel = l10n.text('rsiOversold');
      zoneColor = AppTheme.accentEmerald;
    } else if (_simulatedRsi > 70) {
      zoneLabel = l10n.text('rsiOverbought');
      zoneColor = AppTheme.accentCrimson;
    } else {
      zoneLabel = l10n.text('rsiNeutral');
      zoneColor = AppTheme.accentCyan;
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Text(
          l10n.text('academyTitle'),
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          l10n.text('academySubtitle'),
          style: const TextStyle(
            fontSize: 13,
            color: AppTheme.textSecondary,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: AppTheme.cardDecoration(highlighted: true),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                l10n.text('rsiLabTitle'),
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'RSI (14): ${_simulatedRsi.toStringAsFixed(0)}',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: zoneColor,
                      fontFeatures: const [FontFeature.tabularFigures()],
                    ),
                  ),
                  Text(
                    zoneLabel,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: zoneColor,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Slider(
                value: _simulatedRsi,
                min: 10,
                max: 90,
                divisions: 80,
                activeColor: zoneColor,
                inactiveColor: AppTheme.hairline,
                onChanged: (value) => setState(() => _simulatedRsi = value),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _LessonCard(
          index: '01',
          title: l10n.text('lesson1Title'),
          body: l10n.text('lesson1Body'),
        ),
        const SizedBox(height: 10),
        _LessonCard(
          index: '02',
          title: l10n.text('lesson2Title'),
          body: l10n.text('lesson2Body'),
        ),
        const SizedBox(height: 10),
        _LessonCard(
          index: '03',
          title: l10n.text('lesson3Title'),
          body: l10n.text('lesson3Body'),
        ),
      ],
    );
  }
}

class _LessonCard extends StatelessWidget {
  const _LessonCard({
    required this.index,
    required this.title,
    required this.body,
  });

  final String index;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: AppTheme.cardDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$index. $title',
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            body,
            style: const TextStyle(
              fontSize: 13,
              height: 1.5,
              color: AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}
