import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';
import '../models/crypto_asset.dart';
import '../state/market_simulation_controller.dart';
import '../theme/app_theme.dart';

class PaperSimulatorScreen extends StatefulWidget {
  const PaperSimulatorScreen({super.key, required this.controller});

  final MarketSimulationController controller;

  @override
  State<PaperSimulatorScreen> createState() => _PaperSimulatorScreenState();
}

class _PaperSimulatorScreenState extends State<PaperSimulatorScreen> {
  OrderSide _side = OrderSide.buy;
  final TextEditingController _qtyController =
      TextEditingController(text: '0.25');

  @override
  void dispose() {
    _qtyController.dispose();
    super.dispose();
  }

  void _submitOrder(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final qty = double.tryParse(_qtyController.text.trim()) ?? -1;
    final status = widget.controller.executePaperOrder(
      symbol: widget.controller.selectedSymbol,
      side: _side,
      quantity: qty,
    );

    String message;
    switch (status) {
      case OrderStatusCode.successBuy:
        message = l10n.text('orderSuccessBuy');
        break;
      case OrderStatusCode.successSell:
        message = l10n.text('orderSuccessSell');
        break;
      case OrderStatusCode.insufficientBalance:
        message = l10n.text('insufficientBalance');
        break;
      case OrderStatusCode.insufficientHoldings:
        message = l10n.text('insufficientHoldings');
        break;
      case OrderStatusCode.invalidQuantity:
        message = l10n.text('invalidQuantity');
        break;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final controller = widget.controller;
    final asset = controller.selectedAsset;
    final parsedQty = double.tryParse(_qtyController.text.trim()) ?? 0;
    final estimatedCost = parsedQty > 0 ? parsedQty * asset.priceUsd : 0.0;
    final pnl = controller.unrealizedPnl;
    final pnlColor =
        pnl >= 0 ? AppTheme.accentEmerald : AppTheme.accentCrimson;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: AppTheme.cardDecoration(highlighted: true),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    l10n.text('virtualBalance'),
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                  TextButton(
                    onPressed: controller.resetPortfolio,
                    child: Text(
                      l10n.text('resetPortfolio'),
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppTheme.accentCyan,
                      ),
                    ),
                  ),
                ],
              ),
              Text(
                '\$${controller.virtualUsdBalance.toStringAsFixed(2)}',
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w700,
                  fontFeatures: [FontFeature.tabularFigures()],
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          l10n.text('portfolioEquity'),
                          style: const TextStyle(
                            fontSize: 11,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '\$${controller.totalVirtualEquity.toStringAsFixed(2)}',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            fontFeatures: [FontFeature.tabularFigures()],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          l10n.text('unrealizedPnl'),
                          style: const TextStyle(
                            fontSize: 11,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${pnl >= 0 ? '+' : ''}\$${pnl.toStringAsFixed(2)}',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: pnlColor,
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: AppTheme.cardDecoration(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                l10n.text('selectAsset'),
                style: const TextStyle(
                  fontSize: 12,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: controller.selectedSymbol,
                dropdownColor: AppTheme.surfaceElevated,
                items: controller.assets
                    .map(
                      (a) => DropdownMenuItem(
                        value: a.symbol,
                        child: Text(
                          '${a.symbol} · ${a.localizedName(l10n.isArabic)} (\$${a.priceUsd.toStringAsFixed(2)})',
                          style: const TextStyle(fontSize: 13),
                        ),
                      ),
                    )
                    .toList(growable: false),
                onChanged: (symbol) {
                  if (symbol != null) controller.selectAsset(symbol);
                },
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: FilledButton(
                      onPressed: () => setState(() => _side = OrderSide.buy),
                      style: FilledButton.styleFrom(
                        backgroundColor: _side == OrderSide.buy
                            ? AppTheme.accentEmerald
                            : AppTheme.surfaceElevated,
                        foregroundColor: _side == OrderSide.buy
                            ? const Color(0xFF031A11)
                            : AppTheme.textSecondary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(l10n.text('buyOrder')),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => setState(() => _side = OrderSide.sell),
                      style: FilledButton.styleFrom(
                        backgroundColor: _side == OrderSide.sell
                            ? AppTheme.accentCrimson
                            : AppTheme.surfaceElevated,
                        foregroundColor: _side == OrderSide.sell
                            ? Colors.white
                            : AppTheme.textSecondary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(l10n.text('sellOrder')),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _qtyController,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  labelText: l10n.text('quantityLabel'),
                  suffixText: asset.symbol,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    l10n.text('estimatedTotal'),
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                  Text(
                    '\$${estimatedCost.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      fontFeatures: [FontFeature.tabularFigures()],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 46,
                child: FilledButton(
                  onPressed: () => _submitOrder(context),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppTheme.accentCyan,
                    foregroundColor: const Color(0xFF04131E),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    l10n.text('executePaperOrder'),
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Text(
          l10n.text('holdingsTitle'),
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        if (controller.holdings.isEmpty)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: AppTheme.cardDecoration(),
            child: Text(
              l10n.text('noHoldings'),
              style: const TextStyle(
                fontSize: 13,
                color: AppTheme.textSecondary,
              ),
            ),
          )
        else
          ...controller.holdings.map((holding) {
            final current = controller.assets
                .firstWhere((a) => a.symbol == holding.symbol);
            final positionPnl =
                (current.priceUsd - holding.avgEntryPrice) * holding.quantity;
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: AppTheme.cardDecoration(),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${holding.symbol} · ${holding.quantity.toStringAsFixed(4)}',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            fontFeatures: [FontFeature.tabularFigures()],
                          ),
                        ),
                        Text(
                          '${l10n.text('avgEntry')}: \$${holding.avgEntryPrice.toStringAsFixed(2)}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: AppTheme.textSecondary,
                            fontFeatures: [FontFeature.tabularFigures()],
                          ),
                        ),
                      ],
                    ),
                    Text(
                      '${positionPnl >= 0 ? '+' : ''}\$${positionPnl.toStringAsFixed(2)}',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: positionPnl >= 0
                            ? AppTheme.accentEmerald
                            : AppTheme.accentCrimson,
                        fontFeatures: const [FontFeature.tabularFigures()],
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
        const SizedBox(height: 16),
        Text(
          l10n.text('orderHistory'),
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        if (controller.orders.isEmpty)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: AppTheme.cardDecoration(),
            child: Text(
              l10n.text('noOrdersYet'),
              style: const TextStyle(
                fontSize: 13,
                color: AppTheme.textSecondary,
              ),
            ),
          )
        else
          ...controller.orders.take(10).map((order) {
            final isBuy = order.side == OrderSide.buy;
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: AppTheme.cardDecoration(),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '${isBuy ? 'BUY' : 'SELL'} ${order.quantity.toStringAsFixed(4)} ${order.symbol}',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: isBuy
                            ? AppTheme.accentEmerald
                            : AppTheme.accentCrimson,
                        fontFeatures: const [FontFeature.tabularFigures()],
                      ),
                    ),
                    Text(
                      '@ \$${order.priceUsd.toStringAsFixed(2)}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppTheme.textSecondary,
                        fontFeatures: [FontFeature.tabularFigures()],
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }
}
