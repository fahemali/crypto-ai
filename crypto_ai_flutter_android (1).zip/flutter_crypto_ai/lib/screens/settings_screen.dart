import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';
import '../state/market_simulation_controller.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.controller});

  final MarketSimulationController controller;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Text(
          l10n.text('settingsTitle'),
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: AppTheme.cardDecoration(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                l10n.text('languageLabel'),
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () =>
                          controller.setLocale(const Locale('en')),
                      style: OutlinedButton.styleFrom(
                        backgroundColor: !l10n.isArabic
                            ? AppTheme.accentCyan.withOpacity(0.16)
                            : AppTheme.surfaceElevated,
                        foregroundColor: !l10n.isArabic
                            ? AppTheme.accentCyan
                            : AppTheme.textSecondary,
                        side: BorderSide(
                          color: !l10n.isArabic
                              ? AppTheme.accentCyan
                              : AppTheme.hairline,
                        ),
                      ),
                      child: const Text('English (LTR)'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () =>
                          controller.setLocale(const Locale('ar')),
                      style: OutlinedButton.styleFrom(
                        backgroundColor: l10n.isArabic
                            ? AppTheme.accentCyan.withOpacity(0.16)
                            : AppTheme.surfaceElevated,
                        foregroundColor: l10n.isArabic
                            ? AppTheme.accentCyan
                            : AppTheme.textSecondary,
                        side: BorderSide(
                          color: l10n.isArabic
                              ? AppTheme.accentCyan
                              : AppTheme.hairline,
                        ),
                      ),
                      child: const Text('العربية (RTL)'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: AppTheme.cardDecoration(),
          child: SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(
              l10n.text('liveTicksLabel'),
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            value: controller.liveTicksEnabled,
            activeColor: AppTheme.accentCyan,
            onChanged: controller.toggleLiveTicks,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: AppTheme.cardDecoration(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                l10n.text('disclaimerTitle'),
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.accentAmber,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                l10n.text('disclaimerBody'),
                style: const TextStyle(
                  fontSize: 13,
                  height: 1.5,
                  color: AppTheme.textSecondary,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
