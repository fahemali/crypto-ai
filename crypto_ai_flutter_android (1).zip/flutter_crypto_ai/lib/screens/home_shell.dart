import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';
import '../state/market_simulation_controller.dart';
import '../theme/app_theme.dart';
import 'academy_screen.dart';
import 'market_dashboard_screen.dart';
import 'paper_simulator_screen.dart';
import 'settings_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.controller});

  final MarketSimulationController controller;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    final pages = [
      MarketDashboardScreen(
        controller: widget.controller,
        onNavigateToSimulator: () => setState(() => _selectedIndex = 1),
      ),
      PaperSimulatorScreen(controller: widget.controller),
      const AcademyScreen(),
      SettingsScreen(controller: widget.controller),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          l10n.text('appTitle'),
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: TextButton(
              onPressed: () {
                widget.controller.setLocale(
                  l10n.isArabic ? const Locale('en') : const Locale('ar'),
                );
              },
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.accentCyan,
              ),
              child: Text(
                l10n.isArabic ? 'EN' : 'عربي',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) =>
            setState(() => _selectedIndex = index),
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.show_chart_outlined),
            selectedIcon: const Icon(Icons.show_chart),
            label: l10n.text('navMarket'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.account_balance_wallet_outlined),
            selectedIcon: const Icon(Icons.account_balance_wallet),
            label: l10n.text('navSimulator'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.school_outlined),
            selectedIcon: const Icon(Icons.school),
            label: l10n.text('navAcademy'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.tune_outlined),
            selectedIcon: const Icon(Icons.tune),
            label: l10n.text('navSettings'),
          ),
        ],
      ),
    );
  }
}
