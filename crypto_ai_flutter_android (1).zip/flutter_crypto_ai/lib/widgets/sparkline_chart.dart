import 'dart:math' as math;
import 'package:flutter/material.dart';

class SparklineChart extends StatelessWidget {
  const SparklineChart({
    super.key,
    required this.points,
    required this.color,
    this.height = 44,
    this.strokeWidth = 2.0,
    this.showArea = true,
  });

  final List<double> points;
  final Color color;
  final double height;
  final double strokeWidth;
  final bool showArea;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _SparklinePainter(
          points: points,
          color: color,
          strokeWidth: strokeWidth,
          showArea: showArea,
        ),
      ),
    );
  }
}

class _SparklinePainter extends CustomPainter {
  _SparklinePainter({
    required this.points,
    required this.color,
    required this.strokeWidth,
    required this.showArea,
  });

  final List<double> points;
  final Color color;
  final double strokeWidth;
  final bool showArea;

  @override
  void paint(Canvas canvas, Size size) {
    if (points.length < 2 || size.width <= 0 || size.height <= 0) return;

    final minVal = points.reduce(math.min);
    final maxVal = points.reduce(math.max);
    final span = (maxVal - minVal).abs() < 1e-9 ? 1.0 : (maxVal - minVal);

    final linePath = Path();
    final areaPath = Path();

    for (int i = 0; i < points.length; i++) {
      final dx = (i / (points.length - 1)) * size.width;
      final normalizedY = (points[i] - minVal) / span;
      final dy = size.height - (normalizedY * (size.height - 6) + 3);
      if (i == 0) {
        linePath.moveTo(dx, dy);
        areaPath.moveTo(dx, size.height);
        areaPath.lineTo(dx, dy);
      } else {
        linePath.lineTo(dx, dy);
        areaPath.lineTo(dx, dy);
      }
    }

    if (showArea) {
      areaPath.lineTo(size.width, size.height);
      areaPath.close();
      final fillPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            color.withOpacity(0.24),
            color.withOpacity(0.0),
          ],
        ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
      canvas.drawPath(areaPath, fillPaint);
    }

    final strokePaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(linePath, strokePaint);
  }

  @override
  bool shouldRepaint(covariant _SparklinePainter oldDelegate) {
    return oldDelegate.points != points ||
        oldDelegate.color != color ||
        oldDelegate.strokeWidth != strokeWidth;
  }
}
