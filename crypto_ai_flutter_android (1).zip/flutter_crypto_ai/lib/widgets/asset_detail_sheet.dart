import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';
import '../models/crypto_asset.dart';
import '../theme/app_theme.dart';
import 'sparkline_chart.dart';

class AssetDetailSheet extends StatelessWidget {
  const AssetDetailSheet({
    super.key,
    required this.asset,
    required this.onPracticeInSimulator,
  });

  final CryptoAsset asset;
  final VoidCallback onPracticeInSimulator;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isPositive = asset.change24hPercent >= 0;
    final trendColor =
        isPositive ? AppTheme.accentEmerald : AppTheme.accentCrimson;

    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(top: BorderSide(color: AppTheme.hairline)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppTheme.hairline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppTheme.surfaceElevated,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.hairline),
                ),
                child: Text(
                  asset.symbol,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    color: AppTheme.accentCyan,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      asset.localizedName(l10n.isArabic),
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      l10n.text('educationalBadge'),
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '\$${asset.priceUsd.toStringAsFixed(asset.priceUsd < 10 ? 3 : 2)}',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      fontFeatures: [FontFeature.tabularFigures()],
                    ),
                  ),
                  Text(
                    '${isPositive ? '+' : ''}${asset.change24hPercent.toStringAsFixed(2)}%',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: trendColor,
                      fontFeatures: const [FontFeature.tabularFigures()],
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.canvas,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppTheme.hairline),
            ),
            child: SparklineChart(
              points: asset.sparkline,
              color: trendColor,
              height: 92,
              strokeWidth: 2.5,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _MetricCell(
                label: l10n.text('marketCap'),
                value: '\$${asset.marketCapBillions.toStringAsFixed(1)}B',
              ),
              const SizedBox(width: 10),
              _MetricCell(
                label: l10n.text('volume24h'),
                value: '\$${asset.volume24hBillions.toStringAsFixed(2)}B',
              ),
              const SizedBox(width: 10),
              _MetricCell(
                label: l10n.text('rsi14'),
                value: asset.rsi14.toStringAsFixed(1),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '${l10n.text('range24h')}: \$${asset.low24h.toStringAsFixed(2)} – \$${asset.high24h.toStringAsFixed(2)}',
            style: const TextStyle(
              fontSize: 12,
              color: AppTheme.textSecondary,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: FilledButton.icon(
              onPressed: () {
                Navigator.of(context).pop();
                onPracticeInSimulator();
              },
              icon: const Icon(Icons.candlestick_chart_outlined, size: 18),
              label: Text(l10n.text('openInSimulator')),
              style: FilledButton.styleFrom(
                backgroundColor: AppTheme.accentCyan,
                foregroundColor: const Color(0xFF04131E),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricCell extends StatelessWidget {
  const _MetricCell({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: AppTheme.surfaceElevated,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.hairline),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11,
                color: AppTheme.textSecondary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                fontFeatures: [FontFeature.tabularFigures()],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
