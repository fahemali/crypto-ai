import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:crypto_ai/main.dart';
import 'package:crypto_ai/models/crypto_asset.dart';
import 'package:crypto_ai/state/market_simulation_controller.dart';

void main() {
  test('Paper simulation controller validates buy, sell, and reset', () {
    final controller = MarketSimulationController(autoStartTimer: false);
    expect(controller.virtualUsdBalance, 100000.0);

    final buyResult = controller.executePaperOrder(
      symbol: 'BTC',
      side: OrderSide.buy,
      quantity: 0.5,
    );
    expect(buyResult, OrderStatusCode.successBuy);
    expect(controller.holdings.length, 1);
    expect(controller.virtualUsdBalance, lessThan(100000.0));

    final invalidSell = controller.executePaperOrder(
      symbol: 'BTC',
      side: OrderSide.sell,
      quantity: 10.0,
    );
    expect(invalidSell, OrderStatusCode.insufficientHoldings);

    controller.resetPortfolio();
    expect(controller.virtualUsdBalance, 100000.0);
    expect(controller.holdings, isEmpty);
    controller.dispose();
  });

  testWidgets('CryptoAiApp renders bilingual toggle and navigation tabs',
      (WidgetTester tester) async {
    await tester.pumpWidget(const CryptoAiApp(autoStartTimer: false));
    await tester.pumpAndSettle();

    expect(find.text('Crypto AI'), findsOneWidget);
    expect(find.text('Market'), findsOneWidget);
    expect(find.text('Paper Lab'), findsOneWidget);

    await tester.tap(find.text('عربي'));
    await tester.pumpAndSettle();

    expect(find.text('السوق'), findsOneWidget);
    expect(find.text('المحاكاة'), findsOneWidget);
  });
}
